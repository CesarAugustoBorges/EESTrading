package Classe;

import java.util.List;

public class ConsoleView extends View {

    public String print(CFD cfd) {
        return null;
    }

    public String print(List<CFD> cfds) {
        return null;
    }
}