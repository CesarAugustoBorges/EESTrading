package Classe;

public class Petroleo extends AtivoFinanceiro {
}