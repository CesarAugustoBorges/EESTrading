package Classe;

public class Moeda extends AtivoFinanceiro {
}