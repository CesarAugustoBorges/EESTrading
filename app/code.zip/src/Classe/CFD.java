package Classe;

public class CFD {

	private double boughtValue;
	private double units;
	private double takeProfit;
	private double stopLoss;
	private int id;
	private AtivoFinanceiro ativoFinanceiro;

	public void getValue() {
		// TODO - implement CFD.getValue
		throw new UnsupportedOperationException();
	}

}