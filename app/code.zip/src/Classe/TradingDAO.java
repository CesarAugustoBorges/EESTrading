package Classe2;

public class TradingDAO {
}