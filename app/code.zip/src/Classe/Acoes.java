package Classe;

public class Acoes extends AtivoFinanceiro {
}