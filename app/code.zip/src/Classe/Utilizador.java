package Classe;

import java.util.List;

public class Utilizador {

	private String username;
	private String password;
	private double money;
	private List<CFD> portfolio;
	private List<CFD> actives;

	/**
	 * 
	 * @param cfd
	 */
	public double buyCFD(CFD cfd) {
		// TODO - implement Utilizador.buyCFD
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param cfd
	 */
	public double sellCFD(CFD cfd) {
		// TODO - implement Utilizador.sellCFD
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param cfd
	 */
	public void addPortfolio(CFD cfd) {
		// TODO - implement Utilizador.addPortfolio
		throw new UnsupportedOperationException();
	}

}