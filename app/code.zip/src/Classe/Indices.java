package Classe;

public class Indices extends AtivoFinanceiro {
}