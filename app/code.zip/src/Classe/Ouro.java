package Classe;

public class Ouro extends AtivoFinanceiro {
}