package Classe;

public abstract class AtivoFinanceiro {

	private String company;
	private double value;

}