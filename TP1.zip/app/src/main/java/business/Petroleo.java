package business;

import business.AtivoFinanceiro;

public class Petroleo extends AtivoFinanceiro {

    public Petroleo(String name,double value){
        super(name,value, "Petroleo");
    }

}