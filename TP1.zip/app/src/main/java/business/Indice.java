package business;

import business.AtivoFinanceiro;

public class Indice extends AtivoFinanceiro {

    public Indice(String name,double value){
        super(name,value,"Indice");
    }

}