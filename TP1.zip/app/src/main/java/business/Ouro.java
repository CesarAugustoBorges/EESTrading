package business;

import business.AtivoFinanceiro;

public class Ouro extends AtivoFinanceiro {

    public Ouro(String name,double value){
        super(name,value,"Ouro");
    }
}