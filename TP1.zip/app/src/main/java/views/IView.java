package views;

public interface IView {
    void render();
}
